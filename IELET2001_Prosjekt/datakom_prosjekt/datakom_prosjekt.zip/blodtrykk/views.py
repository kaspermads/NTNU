from django.shortcuts import render
from django.http import HttpResponse
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import SensorData
from .models import Pasient
from django.template import loader
from rest_framework import viewsets
from .serializers import PasientSerializer
from rest_framework import permissions


# Create your views here.

def test1(request):
    template = loader.get_template('test1.html')
    return HttpResponse(template.render())


def test2(request):
    mypasienter = Pasient.objects.all().values()
    template = loader.get_template('index.html')
    context = {
        "mypasienter": mypasienter
    }
    return HttpResponse(template.render(context, request))


def pasient_data(request, id):
    mypasienter = Pasient.objects.get(id=id)


class PasientViewSet(viewsets.ModelViewSet):
    serializer_class = PasientSerializer
    queryset = Pasient.objects.all()
    permission_classes = [permissions.IsAuthenticated]
