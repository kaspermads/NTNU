from rest_framework import serializers
from . import models


class PasientSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Pasient
        fields = '__all__'
